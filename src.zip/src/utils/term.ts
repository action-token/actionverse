import { env } from "~/env";

export const CREATOR_TERM = env.NEXT_PUBLIC_PLATFORM_CREATOR_TERM;

export const CREATOR_PLURAL_TERM = `${CREATOR_TERM}s`;
