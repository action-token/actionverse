
const Post = () => {
    return (

        <h1>Post</h1>

    );
}
export default Post;