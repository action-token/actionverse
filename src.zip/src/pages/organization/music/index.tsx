import CreatorLayout from "~/components/layout/root/CreatorLayout";

const Music = () => {
    return (

        <h1>Music</h1>

    );
}
export default Music;