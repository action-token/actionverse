import { env } from "~/env";

export const MOTHER_SECRET = env.MOTHER_SECRET;
export const STORAGE_SECRET = env.STORAGE_SECRET;
