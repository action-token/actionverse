export enum WalletType {
    none = "none",
    albedo = "albedo",
    walletConnect = "walletConnect",
    frieghter = "frieghter",
    xBull = "xBull",
    rabet = "rabet",
    facebook = "facebook",
    google = "google",
    emailPass = "emailPass",
    isAdmin = "isAdmin",
    apple = "apple",
}
