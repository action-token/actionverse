import { ConnectWalletButton } from "package/connect_wallet";

export default ConnectWalletButton;
